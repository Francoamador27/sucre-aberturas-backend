<?php

namespace App\Http\Controllers;

use App\Models\Document;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class DocumentController extends Controller
{
public function index(Request $request)
{

    $q        = trim((string) $request->query('q', ''));
    $fileQ    = trim((string) $request->query('file', ''));
    $idpa     = $request->query('idpa'); // puede venir string
    $sort     = $request->query('sort', 'fere');
    $dir      = strtolower($request->query('dir', 'desc')) === 'asc' ? 'asc' : 'desc';
    $perPage  = (int) $request->query('per_page', 12);

    // Columnas permitidas para ordenar (evita SQL injection)
    // Ajustá según tus columnas reales en `document`
    $sortable = ['id', 'title', 'fere', 'idpa', 'created_at', 'updated_at', 'nomfi'];
    if (!in_array($sort, $sortable, true)) {
        $sort = 'fere'; // por defecto ordena por fecha de registro que guardás
    }

    $query = Document::query()
        // opcional: incluye datos mínimos del paciente
        ->with(['patient:idpa,nompa,apepa']);

    // Búsqueda full-text sencilla: title / descripcion
    if ($q !== '') {
        $query->where(function ($w) use ($q) {
            $w->where('title', 'like', "%{$q}%")
              ->orWhere('descripcion', 'like', "%{$q}%");
        });
    }

    // Búsqueda por nombre/ruta de archivo (nomfi)
    if ($fileQ !== '') {
        $query->where('nomfi', 'like', "%{$fileQ}%");
    }

    // Filtro por paciente
    if ($idpa !== null && $idpa !== '') {
        $query->where('idpa', (int) $idpa);
    }

    // Orden + paginación
    $paginator = $query->orderBy($sort, $dir)->paginate($perPage);

    // Helper URL absoluta
    $isAbsoluteUrl = static function ($url) {
        return is_string($url) && preg_match('#^https?://#i', $url);
    };

    // Normalizar URL pública de nomfi
    $paginator->getCollection()->transform(function ($item) use ($isAbsoluteUrl) {
        if (!empty($item->nomfi) && !$isAbsoluteUrl($item->nomfi)) {
            $item->nomfi_url = asset($item->nomfi); // agrega campo derivado
        } else {
            $item->nomfi_url = $item->nomfi;
        }

        // (Opcional) nombre completo del paciente si lo tenés en el accessor
        if ($item->relationLoaded('patient') && $item->patient) {
            $item->patient_full_name = method_exists($item->patient, 'getFullNameAttribute')
                ? $item->patient->full_name
                : trim(($item->patient->nompa ?? '').' '.($item->patient->apepa ?? ''));
        }

        return $item;
    });

    return response()->json($paginator);
}


    public function show(string $idOrSlug)
    {
        $query = \App\Models\Document::query();

        $servicio = ctype_digit($idOrSlug)
            ? $query->findOrFail((int) $idOrSlug)
            : $query->where('slug', $idOrSlug)->firstOrFail();

        $servicio->image = $servicio->image ? asset($servicio->image) : null;
        $servicio->mainImage = $servicio->mainImage ? asset($servicio->mainImage) : null;
        if (is_array($servicio->gallery)) {
            $servicio->gallery = array_map(fn($g) => asset($g), $servicio->gallery);
        }

        return response()->json(['data' => $servicio]);
    }
    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'descripcion' => ['required', 'string'],
            'idpa' => ['required', 'integer', 'exists:patients,idpa'],
            'document' => [
                'required',
                'file',
                'max:10240', // 10MB
                'mimetypes:image/jpeg,image/png,image/webp,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            ],
            // 'fere' => ['nullable','date'], // por si te llega
        ]);

        // Fecha por defecto (YYYY-MM-DD) si no viene
        if (!$request->filled('fere')) {
            $data['fere'] = now()->toDateString();
        } else {
            $data['fere'] = $request->input('fere');
        }

        // === Guardado de archivo EXACTO al esquema que mostraste ===
        // 1) Se mueve físicamente a /public/storage/uploads/servicios/
        $uploadDir = public_path('storage/uploads/documentos/');
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $file = $request->file('document');
        $name = Str::uuid() . '.' . $file->getClientOriginalExtension();
        $file->move($uploadDir, $name);

        // 2) La ruta pública se construye como /storage/uploads/documentos/{archivo}
        //    (sí, distinto del dir físico, tal cual lo tenías)
        $publicPath = 'storage/uploads/documentos/' . $name;

        // Compat: si en algún lado consumís estas claves en la respuesta
        $data['document'] = $publicPath;
        $data['image'] = $publicPath;

        // Lo que realmente persiste en tu tabla `document`
        // (según tu $fillable: title, descripcion, nomfi, fere, idpa)
        $doc = Document::create([
            'title' => $data['title'],
            'descripcion' => $data['descripcion'],
            'nomfi' => $publicPath,   // <- acá va la ruta que venías guardando
            'fere' => $data['fere'],
            'idpa' => $data['idpa'],
        ]);

        // Opcional: devolver también las claves de compatibilidad
        $payload = $doc->toArray();
        $payload['document'] = $publicPath;
        $payload['image'] = $publicPath;

        return response()->json($payload, 201);
    }
   public function destroy(Document $document)
{
    // Nomfi puede ser relativa (storage/...) o absoluta (http...)
    $path = $document->nomfi;
    $isAbsolute = is_string($path) && preg_match('#^https?://#i', $path);

    if ($path && !$isAbsolute) {
        $full = public_path($path); // => public/storage/uploads/documentos/xxx.ext
        try {
            if (is_file($full)) {
                @unlink($full);
            } else {
                // fallback defensivo por si hay cambios de carpeta
                $alt = public_path(str_replace('/documentos/', '/servicios/', $path));
                if (is_file($alt)) {
                    @unlink($alt);
                }
            }
        } catch (\Throwable $e) {
            Log::warning('No se pudo eliminar el archivo del documento', [
                'document_id' => $document->id,
                'path'        => $path,
                'error'       => $e->getMessage(),
            ]);
        }
    }

    $document->delete();

    return response()->noContent(); // 204
}

}
