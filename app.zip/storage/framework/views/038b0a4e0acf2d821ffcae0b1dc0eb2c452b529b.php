<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'url' => config('app.frontend_url', config('app.url')),
    'logo' => config('app.branding.logo_url') ?: env('MAIL_LOGO_URL'),
    'logoWidth' => (int) (config('app.branding.logo_width') ?: env('MAIL_LOGO_WIDTH', 180)),
    'logoHeight' => config('app.branding.logo_height') ?: env('MAIL_LOGO_HEIGHT', 'auto'),
    'backgroundColor' => '#ffffff',
    'textColor' => '#2c3e50',
    'borderColor' => '#e9ecef',
    'gradient' => false,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'url' => config('app.frontend_url', config('app.url')),
    'logo' => config('app.branding.logo_url') ?: env('MAIL_LOGO_URL'),
    'logoWidth' => (int) (config('app.branding.logo_width') ?: env('MAIL_LOGO_WIDTH', 180)),
    'logoHeight' => config('app.branding.logo_height') ?: env('MAIL_LOGO_HEIGHT', 'auto'),
    'backgroundColor' => '#ffffff',
    'textColor' => '#2c3e50',
    'borderColor' => '#e9ecef',
    'gradient' => false,
]); ?>
<?php foreach (array_filter(([
    'url' => config('app.frontend_url', config('app.url')),
    'logo' => config('app.branding.logo_url') ?: env('MAIL_LOGO_URL'),
    'logoWidth' => (int) (config('app.branding.logo_width') ?: env('MAIL_LOGO_WIDTH', 180)),
    'logoHeight' => config('app.branding.logo_height') ?: env('MAIL_LOGO_HEIGHT', 'auto'),
    'backgroundColor' => '#ffffff',
    'textColor' => '#2c3e50',
    'borderColor' => '#e9ecef',
    'gradient' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $appName = config('app.name', 'Mi Aplicación');
    $headerStyle = $gradient
        ? 'background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color:#ffffff;'
        : "background-color: {$backgroundColor}; color: {$textColor};";
    $nameColor = $gradient ? '#ffffff' : $textColor;
?>

<tr>
    <td style="<?php echo e($headerStyle); ?> padding:24px 20px; text-align:center; border-bottom:2px solid <?php echo e($borderColor); ?>;">
        <a href="<?php echo e($url); ?>" style="text-decoration:none; display:inline-block;">
            <table role="presentation" cellpadding="0" cellspacing="0" border="0" align="center" style="margin:0 auto;">
                <?php if(filled($logo)): ?>
                    <tr>
                        <td align="center" style="padding:0 0 8px;">
                            <img
                                src="<?php echo e($logo); ?>"
                                alt="<?php echo e($appName); ?>"
                                width="<?php echo e($logoWidth); ?>"
                                <?php if($logoHeight !== 'auto'): ?> height="<?php echo e((int) $logoHeight); ?>" <?php endif; ?>
                                style="display:block; border:0; outline:none; text-decoration:none; height:auto; max-width:100%;"
                            >
                        </td>
                    </tr>
                <?php endif; ?>
                <tr>
                    <td align="center">
                        <div style="
                            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif;
                            font-size:22px; font-weight:700; letter-spacing:-0.3px;
                            color: <?php echo e($nameColor); ?>;
                        ">
                            <?php echo e($slot ?: $appName); ?>

                        </div>
                    </td>
                </tr>
            </table>
        </a>
    </td>
</tr>
<?php /**PATH C:\laragon\www\dentalcoresoftware\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>