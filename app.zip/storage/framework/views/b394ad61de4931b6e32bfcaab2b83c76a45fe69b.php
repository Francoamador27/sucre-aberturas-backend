<?php
    $nombre   = $datos['nombre']   ?? '¡Hola!';
    $email    = $datos['email']    ?? null;
    $telefono = $datos['telefono'] ?? null;
    $asunto   = $datos['asunto']   ?? 'Consulta general';
    $mensaje  = trim($datos['mensaje'] ?? '');
?>

<?php $__env->startComponent('mail::message'); ?>
# <?php echo e($nombre); ?>


Gracias por escribirnos. **Recibimos tu consulta** y en breve un representante se pondrá en contacto contigo.

<?php $__env->startComponent('mail::panel'); ?>
**Resumen de tu consulta**

- **Asunto:** <?php echo e($asunto); ?>

<?php if($telefono): ?>
- **Teléfono:** <?php echo e($telefono); ?>

<?php endif; ?>
<?php if($email): ?>
- **Email:** <?php echo e($email); ?>

<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::panel'); ?>
**Mensaje:**
<br>
<?php echo nl2br(e($mensaje)); ?>

<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::button', ['url' => config('app.url'), 'color' => 'primary']); ?>
Visitar <?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>

> Si esta consulta fue un error, simplemente ignorá este mensaje.

<?php $__env->slot('subcopy'); ?>
Si necesitás adjuntar información o ampliar detalles, podés responder directamente a este email.  
**Referencia:** <?php echo e(now()->format('Ymd-His')); ?>

<?php $__env->endSlot(); ?>

Saludos,  
**<?php echo e(config('app.name')); ?>**
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\laragon\www\dentalcoresoftware\resources\views/emails/contacto_cliente.blade.php ENDPATH**/ ?>