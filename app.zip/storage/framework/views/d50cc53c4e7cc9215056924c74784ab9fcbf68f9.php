<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\dentalcoresoftware\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>