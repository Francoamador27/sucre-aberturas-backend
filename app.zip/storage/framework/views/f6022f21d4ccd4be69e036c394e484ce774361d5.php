<?php $__env->startComponent('mail::message'); ?>
# Nuevo mensaje de contacto

**Nombre:** <?php echo e($datos['nombre']); ?>  
**Email:** <?php echo e($datos['email']); ?>  
**Teléfono:** <?php echo e($datos['telefono']); ?>


**Mensaje:**

<?php echo e($datos['mensaje']); ?>


<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\laragon\www\dentalcoresoftware\resources\views/emails/contacto.blade.php ENDPATH**/ ?>