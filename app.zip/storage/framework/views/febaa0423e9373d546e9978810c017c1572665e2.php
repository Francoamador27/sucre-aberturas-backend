[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\laragon\www\dentalcoresoftware\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>